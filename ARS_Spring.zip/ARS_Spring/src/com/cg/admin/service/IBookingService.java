package com.cg.admin.service;

import java.util.List;

import com.cg.admin.dto.BookingInformation;
import com.cg.admin.dto.FlightInformation;

public interface IBookingService
{
	
	public int bookTicket(BookingInformation bi);
	public List<String> getAllSourceCities();
	public List<String> getAllDestinationCities();
	public List<FlightInformation> getAllFlights(String src, String des);
	public FlightInformation getParticularFlight(int fNo);
	public int addFlight(FlightInformation fi);

	
}

package com.cg.admin.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.admin.dto.BookingInformation;
import com.cg.admin.dto.FlightInformation;
import com.cg.admin.service.IBookingService;

@Controller
public class MyController 
{	
	
	@Autowired
	IBookingService bookingservice;
	
	@RequestMapping(value="all", method=RequestMethod.GET)
	public String getAll(Model model)
	{
		//model.addAttribute("my", new FlightInformation());
		return "home";
	}
	
	@RequestMapping(value="check", method=RequestMethod.POST)
	public String validateAdmin(@ModelAttribute("my") FlightInformation fi)
	{
		
		return "loginsuccess";
		
	}
	
	@RequestMapping(value="insertdata", method=RequestMethod.POST)
	public String validateAdmin1(@ModelAttribute("my") FlightInformation fi)
	{
		bookingservice.addFlight(fi);
		return "insertSuccess";
		
	}
	
	
	@RequestMapping(value="customer", method=RequestMethod.GET)
	public String customerWelcome(Model model)
	{
		List<String> myList = bookingservice.getAllSourceCities();
		List<String> myList1 = bookingservice.getAllDestinationCities();
		model.addAttribute("my",new  FlightInformation());
		model.addAttribute("source",myList);
		model.addAttribute("destination", myList1);
		return "searchFlights";
	}
	
	@RequestMapping(value="showFlights", method=RequestMethod.GET)
	public ModelAndView searchFlight(@ModelAttribute("my") FlightInformation fi)
	{
		System.out.println(fi.getDeptCity());
		List<FlightInformation> myList = bookingservice.getAllFlights(fi.getDeptCity(), fi.getArrCity());
//		model.addAttribute("my",new  FlightInformation());
//		model.addAttribute("fInfo",myList);
		return new ModelAndView("viewFlights", "fInfo", myList);
	}

	
	@RequestMapping(value="book",  method=RequestMethod.GET)
	public ModelAndView bookFlight(@RequestParam("id") int fNo,@ModelAttribute("my") BookingInformation bi)
	{
		System.out.println(fNo);
		FlightInformation fi=bookingservice.getParticularFlight(fNo);
		System.out.println(fi.getDeptCity());
		
		return new ModelAndView("bookFlight", "temp", fi);

	}
	
}

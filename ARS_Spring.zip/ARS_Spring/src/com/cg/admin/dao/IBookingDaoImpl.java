package com.cg.admin.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.admin.dto.BookingInformation;
import com.cg.admin.dto.FlightInformation;

@Repository("bookingdao")
public class IBookingDaoImpl implements IBookingDao 
{
	@PersistenceContext
	EntityManager em;
	
	@Override
	public int bookTicket(BookingInformation bi)
	{
		em.persist(bi);
		em.flush();
		return bi.getBookingId();
	}

	@Override
	public List<String> getAllSourceCities() 
	{
		Query qry=em.createQuery("SELECT distinct deptCity from FlightInformation");
		List<String> myList=qry.getResultList();
		return myList;
	}

	@Override
	public List<String> getAllDestinationCities() 
	{
		Query qry=em.createQuery("SELECT distinct arrCity from FlightInformation");
		List<String> myList=qry.getResultList();
		return myList;
	}

	@Override
	public List<FlightInformation> getAllFlights(String src, String des) 
	{
		Query qry=em.createQuery("Select f from FlightInformation f WHERE f.deptCity=:src AND f.arrCity=:des");
		qry.setParameter("src", src);
		qry.setParameter("des", des);
		List<FlightInformation> myList=qry.getResultList();
		return myList;
	}

	@Override
	public FlightInformation getParticularFlight(int fNo) 
	{
		Query qry=em.createQuery("Select f from FlightInformation f Where f.flightNo=:fNo");
		qry.setParameter("fNo", fNo);
		FlightInformation fi=(FlightInformation) qry.getSingleResult();
		return fi;
	}

	@Override
	public int addFlight(FlightInformation fi) 
	{
		em.persist(fi);
		em.flush();
		return fi.getFlightNo();
	}
	
	
	
}

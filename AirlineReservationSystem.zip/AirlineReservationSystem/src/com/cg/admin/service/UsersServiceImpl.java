package com.cg.admin.service;

import java.util.regex.Pattern;

import com.cg.admin.dao.UsersDao;
import com.cg.admin.dao.UsersDaoImpl;
import com.cg.admin.dto.Users;
import com.cg.admin.exception.UserException;

public class UsersServiceImpl implements UsersService
{
  UsersDao uDao=new UsersDaoImpl();
	@Override
	public int insertUser(Users user) throws UserException 
	{
		
		return uDao.insertUser(user);
	}

	@Override
	public boolean fetchParticularUser(String username, String password)
			throws UserException 
	{
		
		return uDao.fetchParticularUser(username, password);
	}

	@Override
	public int fetchRole(String username, String password) throws UserException 
	{
		
		return uDao.fetchRole(username, password);
	}

	@Override
	public boolean validateMobileNo(long mNo) throws UserException 
	{
		String mobPattern = "[7-9][0-9]{9}";
		if(Pattern.matches(mobPattern,new Long(mNo).toString()))
		{
			return true;
		}
		else
		{
			System.err.println("Please enter valid mobile enter eg: 9871452630");
			return false;
		}
	}

	@Override
	public boolean validateUsername(String uName) throws UserException 
	{
		String cnamePattern="[A-Z][A-Za-z]{2,30}";
		if(Pattern.matches(cnamePattern,uName))
				{
			return true;
				}
		else
		{
		System.err.println("Valid value should contain maximum 30 alphabets. "
				+ "\nOut of 30 Characters, first character should be in UPPERCASE."
				+ "\nUserName cannot be empty.");	
		return false;
		}

	}

	@Override
	public boolean validatePassword(String uPwd) throws UserException 
	{
		String cnamePattern="((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%]).{6,20})";
		if(Pattern.matches(cnamePattern,uPwd))
				{
			return true;
				}
		else
		{
			System.err.println("Valid password must contain"
				+ "\n1. minimum 6 characters"
				+ "\n2. one uppercase is required"
				+ "\n3. one lowercase is required"
				+ "\n4. one digit is required"
				+ "\n5. one special character such as $,@,%,# is must"
				+ "\n6. maximum 20 characters ");	
		return false;
		}
	}

}

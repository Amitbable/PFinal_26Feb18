package com.cg.admin.junit;

import junit.framework.Assert;

import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.admin.dao.BookingInfoDao;
import com.cg.admin.dao.BookingInfoDaoImpl;
import com.cg.admin.dao.UsersDaoImpl;
import com.cg.admin.dto.BookingInformation;
import com.cg.admin.dto.Users;
import com.cg.admin.exception.BookingException;
import com.cg.admin.exception.UserException;

public class TestCasesBooking
{
	
	static BookingInfoDao bDao=null;
	static BookingInformation bInfo=null;
	
	@BeforeClass
	public static void beforeClass() throws BookingException
	{
		bDao=new BookingInfoDaoImpl();
		bInfo=new BookingInformation(1001,32,"abhishek@gmail.com",2,"Business",2500.0,"2,3","7654654387650987","delhi","pune");
	}
	
	@Test
	public void testInsert() throws BookingException
	{
		Assert.assertNotNull(bDao.addNewBookingInformation(bInfo));
	}
	
	@Test
	public void testSearch() throws BookingException
	{
		Assert.assertNotNull(bDao.searchFlightInformation("delhi", "pune"));
	}
	
	@Test
	public void testGetBookingInfo() throws BookingException
	{
		Assert.assertNotNull(bDao.getBookingInformation(38));
	}
}

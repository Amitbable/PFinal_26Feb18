package com.cg.admin.junit;

import java.time.LocalDate;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.admin.dao.FlightInfoDao;
import com.cg.admin.dao.FlightInfoDaoImpl;
import com.cg.admin.dto.FlightInformation;
import com.cg.admin.exception.AdminException;
import com.cg.admin.exception.FlightException;

public class TestCasesFlightSchedule 
{
	
	static FlightInfoDao fDao=null;
	static FlightInformation fInfo=null;
	
	@BeforeClass
	public static void beforeClass() throws AdminException
	{
		fDao=new FlightInfoDaoImpl();
		fInfo=new FlightInformation(1004,"vistara","delhi","mumbai",LocalDate.now(),LocalDate.now(),"13:25","14:04",40,4000.0,20,8000.0,32,15);
	}
	
	@Test
	public void testInsertFlight() throws AdminException
	{
		Assert.assertNotNull(fDao.insertFlightInformation(fInfo));
	}
	
	@Test
	public void testGetFlight() throws  AdminException,FlightException
	{
		Assert.assertNotNull(fDao.getFlight(1001, LocalDate.now()));
	}
	
	
	
}

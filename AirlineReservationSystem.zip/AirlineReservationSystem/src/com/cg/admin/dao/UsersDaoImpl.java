package com.cg.admin.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;




import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.admin.dto.Users;
import com.cg.admin.exception.UserException;
import com.cg.admin.util.DBUtil;

public class UsersDaoImpl implements UsersDao
{
	Logger userLogger=null;
	Connection conn;

	
	public UsersDaoImpl() 
	{
		PropertyConfigurator.configure("resources/log4j.properties");
    	userLogger=Logger.getLogger("UsersDaoImpl.class");
	}

	@Override
	public int insertUser(Users user) throws UserException 
	{
		int dataAdded;
		PreparedStatement pst;
		try {
			conn=DBUtil.getCon();
			pst = conn.prepareStatement(QueryMapper.INSERT_USER);
			pst.setString(1, user.getUsername());
			pst.setString(2, user.getPassword());
			pst.setString(3, user.getRole());
			pst.setLong(4, user.getMobileNo());
			dataAdded=pst.executeUpdate();
			userLogger.log(org.apache.log4j.Level.INFO,"User Inserted"+ user );
		
			
		} 
		catch (Exception e) 
		{
			
			throw new UserException("Problem in inserting User Details"+e.getMessage());
		} 
		return dataAdded;
	}

	@Override
	public boolean fetchParticularUser(String username, String password)
			throws UserException 
	{
		ResultSet rs = null;
		PreparedStatement pst;
		try 
		{
			conn=DBUtil.getCon();
			pst = conn.prepareStatement(QueryMapper.CHECK_USERNAME);
			pst.setString(1, password);
			rs = pst.executeQuery();
			rs.next();
			String id = rs.getString(1);
			userLogger.log(org.apache.log4j.Level.INFO,"Info Fetched"+ id );

//			userLogger.log(Level.INFO,"Info Fetched "+id);
			if(id.equals(username)) 
			{
				return true;
				
			}
			else 
				return false;

		} 
		catch (Exception e) 
		{
			throw new UserException("Problem in fetching Particular User"+e.getMessage());
		} 
		
		
	}

	@Override
	public int fetchRole(String username, String password) throws UserException 
	{
		ResultSet rs = null;
		PreparedStatement pst;
		try 
		{
			conn=DBUtil.getCon();
			pst = conn.prepareStatement(QueryMapper.CHECK_ROLE);
			pst.setString(1, username);
			pst.setString(2, password);
			rs = pst.executeQuery();
			rs.next();
			String role = rs.getString(1);
			userLogger.log(org.apache.log4j.Level.INFO,"Role Fetched"+ role );
//			userLogger.log(Level.INFO,"Role Fetched "+ role);
			if(role.equals("Admin"))
			{
				return 1;
			}
			else if(role.equals("Executive"))
			{
				return 2;
			}
			else
			{
				return 0;
			}
		} 
		catch (Exception e) 
		{
			throw new UserException("Problem in Fetching Role"+e.getMessage());
		} 
		
	}

}
